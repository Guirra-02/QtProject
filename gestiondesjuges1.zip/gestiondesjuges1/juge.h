#ifndef JUGE_H
#define JUGE_H
#include <QSqlQueryModel>
#include <QtDebug>
#include <QtSql>
#include <QString>

class juge
{
public:
    juge();
   juge (int , QString , QString ,QString ,QString ,QString,QString);
         int getid();
        QString getnum();
        QString getnom();
        QString getprenom();
        QString getgrade();
        QString getdateN();
        QString getlieuN();




        void setid(int);
        void setnom(QString);
        void setprenom(QString);
        void setdateN(QString);
        void setlieuN(QString);
        void setnum(QString);
        void setgrade(QString);
        bool ajouter();
        QSqlQueryModel* afficher();
        bool supprimer(int);
        bool modifier (int num);


private:
        QString nom , prenom , dateN , lieuN , grade, num ;
        int id;


};

#endif // JUGE_H
