#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "juge.h"
#include "QMessageBox"
#include "QSqlQueryModel"
#include <QIntValidator>
#include <QObject>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->id->setValidator(new QIntValidator(100, 99999999, this));
    ui->tableView->setModel(J.afficher());
     QSqlDatabase mydb=QSqlDatabase::addDatabase("QSQLITE");
     mydb.setDatabaseName("C:/oraclexe/app/oracle/product/11.2.0server/Get_Started.url");

}

MainWindow::~MainWindow()
{
    delete ui;
}




void MainWindow::on_ajout_clicked()
{
        int id= ui->id->text().toInt();
        QString nom=ui->nom->text();
        QString prenom=ui->prenom->text();
        QString grade=ui->grade->text();
        QString dateN=ui->dateN->text();
        QString lieuN=ui->lieuN->text();
        QString num=ui->num->text();
        juge J(id,nom,prenom,grade,lieuN,dateN,num);
        bool test= J.ajouter();

        if(test){

   ui->tableView->setModel(J.afficher());
            QMessageBox::information(nullptr,QObject::tr("ajout!"),
                                     QObject::tr("ajout successful .\n"
                                                 "click cancel to exit"), QMessageBox::Cancel);
        }

        else
            QMessageBox::critical(nullptr,QObject::tr("ajout!"),
                                     QObject::tr("ajout failed .\n"
                                                 "click cancel to exit"), QMessageBox::Cancel);



      }
void MainWindow::on_supp_clicked()
{
    juge J1 ; J1.setnom(ui->lineEdit_2->text());
        bool test=J1.supprimer(J1.getid());
        if(test){

              ui->tableView->setModel(J1.afficher());

              QMessageBox::information(nullptr,QObject::tr(" OK"),
                                       QObject::tr("Suppression effectuée\n"
                                                   "Click Cancel to exit."),QMessageBox::Cancel);
              ui->tableView->setModel(J1.afficher());

        }
          else{
              QMessageBox::critical(nullptr,QObject::tr("Not OK"),
                                    QObject::tr("Suppression non effectué\n"
                                                "Click Cancel to exit."),QMessageBox::Cancel);
              ui->nom->clear();
              ui->id->clear();
              ui->prenom->clear();
              ui->dateN->clear();
              ui->lieuN->clear();
              ui->grade->clear();
              ui->num->clear();

    }
}

void MainWindow::on_modif_clicked()
{
    int id= ui->id->text().toInt();
    QString nom=ui->nom->text();
    QString prenom=ui->prenom->text();
    QString grade=ui->grade->text();
    QString dateN=ui->dateN->text();
    QString lieuN=ui->lieuN->text();
    QString num=ui->label_7->text();
    juge J(id,nom,prenom,grade,lieuN,dateN,num);
    bool test= J.modifier(id);
    if(test){

ui->tableView->setModel(J.afficher());
        QMessageBox::information(nullptr,QObject::tr("modif!"),
                                 QObject::tr("mod successful .\n"
                                             "click cancel to exit"), QMessageBox::Cancel);
    }

    else
        QMessageBox::critical(nullptr,QObject::tr("modif!"),
                                 QObject::tr("mod failed .\n"
                                             "click cancel to exit"), QMessageBox::Cancel);



}
