#ifndef EMAIL_H
#define EMAIL_H

#include "adresseemail.h"

class email
{
public:
    email();
   email(adresseemail comptegoogle,
         adresseemail  from,
         adresseemail  to,
          QString subject,
          QString contenu);

    adresseemail getComptegoogle();
  adresseemail getFrom();
    adresseemail getTo();
    QString getSubject();
    QString getContenu();

    void setComptegoogle(const adresseemail cgoogle);
    void setFrom(const adresseemail from);
    void setTo(const adresseemail to);
    void setSubject(QString subject);
    void setContenu(QString contenu);

private:
    adresseemail Comptegoogle;
    adresseemail From;
    adresseemail To;
    QString Subject;
    QString Contenu;
};


#endif // EMAIL_H
