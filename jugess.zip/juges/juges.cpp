#include "juges.h"

juges::juges()
{

}
