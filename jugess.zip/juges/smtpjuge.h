#ifndef SMTPJUGE_H
#define SMTPJUGE_H

#include <QObject>
#include <QTimer>
#include <QtNetwork/QSslSocket>
#include <QtNetwork/QAbstractSocket>
#include "email.h"
#include "adresseemail.h"
#include "QString"
#include <QObject>
#include <QTextStream>
#include <QDebug>
#include <QtWidgets/QMessageBox>
#include <QByteArray>
#include <QFile>
#include <QFileInfo>

namespace Status {
    enum e{
        Success,
        Failed
    };
}

class smtpjuge :public QObject
{
    Q_OBJECT



public:
    smtpjuge();
    smtpjuge(QString host,
             int port = 465,
             int conTimeout = 30000,
             int timeout = 60000);
             void envoiemail(email mail);
    ~smtpjuge();




signals:
  void status(Status::e status,QString errorMessage = "");
private slots:
  void comunication();
  void stopCom();

private:
  enum etats{
      Tls,
      HandShake,
      Auth,
      User,
      Pass,
      Rcpt,
      Mail,
      Data,
      Init,
      Body,
      Quit,
      Close,
      email,
  };
  QString Host;
  int Port;
  int ConTimeout;
  int Timeout;
   //email mail;
  QSslSocket *socket;
  QTextStream *textstream;
  int etat;
  QString reponse;
};


#endif // SMTPJUGE_H
