#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtGui/QIntValidator>
#include<QMessageBox>
#include <QPushButton>
#include "connection.h"
#include<QString>
#include<QSqlQuery>
#include<QSqlQueryModel>
#include<QtDebug>
#include<QObject>
#include <QMainWindow>
#include <QTabWidget>
#include <QIntValidator>
#include <QMessageBox>
#include "audience.h"



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{    QString id,type,date;
     id=ui->id->text();
      date=ui->dateEdit->text();

       if(ui->radioButton->isChecked())
           type="Contravention";
       if(ui->radioButton_2->isChecked())
                  type="Délit";
        if(ui->radioButton_3->isChecked())
                   type="Crime";


   audience a(id,date,type);
      bool test=a.ajouter();
       QMessageBox msgBox;
       if(test)
       {
       msgBox.setText("ajout avec succes.");
       ui->tab_etudiant->setModel(a.afficher());
       }
       else
            msgBox.setText("échec d'ajout");
            msgBox.exec();

}

void MainWindow::on_pushButton_2_clicked()
{
QString id=ui->idsupp->text();
qDebug()<<id;
audience a;
bool test=a.supprimer(id);
 QMessageBox msgBox;
 if(test)
 {
 msgBox.setText("supp avec succes.");
 ui->tab_etudiant->setModel(a.afficher());
 }
 else
      msgBox.setText("échec de suppression");

 msgBox.exec();
}

void MainWindow::on_pushButton_3_clicked()
{
    QString id,type,date;
         id=ui->id->text();
          date=ui->dateEdit->text();

           if(ui->radioButton->isChecked())
               type="Contravention";
           if(ui->radioButton_2->isChecked())
                      type="Délit";
            if(ui->radioButton_3->isChecked())
                       type="Crime";


       audience a(id,date,type);
          bool test=a.modifier();
           QMessageBox msgBox;
           if(test)
           {
           msgBox.setText("Modification avec succes.");
           ui->tab_etudiant->setModel(a.afficher());
           }
           else
                msgBox.setText("échec de modification");
                msgBox.exec();
}
