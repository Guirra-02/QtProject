#ifndef ETUDIANT_H
#define ETUDIANT_H
#include<QString>
#include<QSqlQuery>
#include<QSqlQueryModel>
class ETUDIANT
{
public:
    ETUDIANT();

    ETUDIANT( QString, QString, QString);

    //getters//
      QString getid();
    QString getnom();
    QString getprenom();

    //setters//
    void setid(QString);
    void setnom(QString);
    void setprenom(QString);

    //fonctionnalité de base relatives a l'etudiant//
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(QString);
private :

    QString  nom , prenom , id ;

};

#endif // ETUDIANT_H
