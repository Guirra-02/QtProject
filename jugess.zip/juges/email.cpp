#include "email.h"

email::email()
{

}
email::email(adresseemail comptegoogle, adresseemail from,adresseemail   to, QString subject, QString contenu)
{
    this->Comptegoogle =comptegoogle;
    this->From = from;
    this->To = to;
    this->Subject = subject;
    this->Contenu = contenu;
}

adresseemail email::getComptegoogle()
{
    return Comptegoogle;
}

adresseemail email::getFrom()
{
    return From;
}

adresseemail email::getTo()
{
    return To;
}

QString email::getSubject()
{
    return Subject;
}

QString email::getContenu()
{
    return Contenu;
}

void email::setComptegoogle(const adresseemail cgoogle)
{
    this->Comptegoogle = cgoogle;
}

void email::setFrom(const adresseemail from)
{
    this->From = from;
}

void email::setTo(const adresseemail to)
{
    this->To = to;
}

void email::setSubject(QString subject)
{
    this->Subject = subject;
}

void email::setContenu(QString contenu)
{
 this->Contenu = contenu;
}
