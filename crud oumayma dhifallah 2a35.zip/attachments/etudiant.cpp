#include "etudiant.h"
#include <QSqlQuery>
#include <QtDebug>
#include "mainwindow.h"
#include <QSqlQuery>
#include <QtDebug>
#include <QString>
#include<QtDebug>
#include<QObject>
#include <QMainWindow>
#include <QDateTime>
#include <QFile>
#include <QMessageBox>
#include <QTimer>
#include<QDateTime>
#include"QDate"
#include <QTime>
#include <QTimer>
#include <QSqlQueryModel>
#include <QtGui/QIntValidator>
#include<QIntValidator>
#include<QMessageBox>
#include<QDesktopServices>
#include<QFileDialog>
#include <QPushButton>
#include "connection.h"
#include<QString>
#include<QSqlQuery>
#include<QSqlQueryModel>
#include<QDoubleValidator>
#include<QtDebug>
#include<QObject>
#include <QMainWindow>
#include <QDateTime>
#include <QFile>
#include <QMessageBox>

#include <QTabWidget>
#include <QTableWidgetItem>
#include <QtDebug>
#include <QIntValidator>
#include <QMessageBox>
#include <QDate>

ETUDIANT::ETUDIANT()
{ id=" " ;
  nom=" ";
  prenom=" ";
 }
ETUDIANT::ETUDIANT( QString id ,QString nom, QString prenom)
  {this->id=id ; this->nom=nom ; this->prenom=prenom ;}
QString ETUDIANT::getid()
{return id ;}
QString ETUDIANT::getnom()
{return nom ;}
QString ETUDIANT::getprenom()
{return prenom;}
void ETUDIANT::setid(QString id )
{this->id=id;}
void ETUDIANT::setnom(QString nom)
{this->nom=nom;}
void ETUDIANT::setprenom(QString prenom)
{this->prenom=prenom;}

bool ETUDIANT:: ajouter()
{

    QSqlQuery query;

          query.prepare("INSERT INTO ETUDIANT (ID , NOM , PRENOM ) "
                        "VALUES (:id, :nom, :prenom)");
          query.bindValue(0, id);
          query.bindValue(1, nom);
          query.bindValue(2, prenom);


    return  query.exec();

}
QSqlQueryModel* ETUDIANT::afficher()
{
  QSqlQueryModel* model=new QSqlQueryModel();



        model->setQuery("SELECT* FROM ETUDIANT");
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("PRENOM"));


return model;

}
bool ETUDIANT::supprimer(QString)
{
    QSqlQuery query;

          query.prepare("Delete from etudiant where id=:id" );

          query.bindValue(0, id);
 return  query.exec();
}
