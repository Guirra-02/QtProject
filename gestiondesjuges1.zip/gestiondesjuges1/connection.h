#ifndef CONNECTION_H
#define CONNECTION_H
#include <QSqlDatabase>


class connection
{
public:
    connection();
    bool createconnect();
};

#endif // CONNECTION_H
