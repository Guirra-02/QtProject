#ifndef JUGES_H
#define JUGES_H


class juges
{
public:
    juges();
};

#endif // JUGES_H
