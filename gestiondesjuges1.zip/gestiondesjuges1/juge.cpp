#include "juge.h"
#include <QString>
#include <QtDebug>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QObject>
#include "juge.h"

juge::juge()
{
   id= 0 ; nom=" " ; prenom=" "; grade=" "; lieuN=" "; dateN=" "; num=" ";



}
juge::juge(int id , QString nom , QString prenom ,QString grade , QString lieuN , QString dateN , QString num )
{
    this->id=id;
    this->nom=nom;
    this->prenom=prenom;
    this->dateN=dateN;
    this->lieuN=lieuN;
    this->grade=grade;
    this->num=num;

}
 int juge::getid(){return id ;}
QString juge::  getnom(){return nom ;}
QString juge::  getdateN(){return dateN ;}
QString juge::  getlieuN(){return lieuN;}
QString juge::  getgrade(){return grade ;}
QString juge::  getnum(){return num ;}

void juge::  setid(int id){this->id=id;}
void juge:: setnom(QString nom){this->nom=nom;}
void juge:: setprenom(QString prenom){this->prenom=prenom ; }
void juge:: setdateN(QString dateN){this->dateN=dateN;}
void juge :: setgrade(QString grade){this->grade=grade;}
void juge:: setnum(QString num){this->num=num;}
void juge:: setlieuN(QString lieuN){this->lieuN=lieuN;}

bool juge::ajouter()

{

    QSqlQuery query;
    QString id_string =QString::number(id);

          query.prepare("INSERT INTO jugemaram(ID, NOM, PRENOM, DATEN,GRADE,LIEUN,NUM) "
                        "VALUES (:ID, :NOM, :PRENOM, :DATEN, :GRADE ,:LIEUN,:NUM)");
          query.bindValue(":ID", id_string);
          query.bindValue(":NOM", nom);
          query.bindValue(":PRENOM", prenom);
          query.bindValue(":DATEN", dateN);
          query.bindValue(":GRADE", grade);
          query.bindValue(":LIEUN", lieuN);
          query.bindValue(":NUM", num);

          return query.exec();
}
bool juge::supprimer(int id)
{
    QSqlQuery query;
    query.prepare("delete from jugemaram where ID=:ID ");

    query.bindValue(":ID", id);

 return query.exec();
}

QSqlQueryModel * juge::afficher()
{

     QSqlQueryModel* model=new QSqlQueryModel();

     model->setQuery("SELECT* FROM jugemaram");
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
     model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
     model->setHeaderData(2, Qt::Horizontal, QObject::tr("PRENOM"));
     model->setHeaderData(3, Qt::Horizontal, QObject::tr("GRADE"));
     model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATEN"));
     model->setHeaderData(5, Qt::Horizontal, QObject::tr("LIEUN"));
     model->setHeaderData(6, Qt::Horizontal, QObject::tr("NUM"));

     return model;
    }
bool juge::modifier(int id)
 {
     QSqlQuery query;
     QString id_string =QString::number(id);
     query.prepare("update jugemaram SET ID=:ID,NOM=:NOM, PRENOM=:PRENOM,NUM=:NUM, LIEUN=:LIEUN , DATEN=:DATEN , GRADE=:GRADE where ID=:ID   " );
     query.bindValue(":ID", id_string);
     query.bindValue(":NOM",nom);
     query.bindValue(":PRENOM", prenom);
     query.bindValue(":GRADE", grade);
     query.bindValue(":LIEUN", lieuN);
     query.bindValue(":DATEN", dateN);
     query.bindValue(":NUM", num);



   return  query.exec();
 }

