#include "audience.h"

audience::audience()
{

}


bool audience::ajouter(){

    QSqlQuery query;

          query.prepare("INSERT INTO AUDIANCE (ID , DATEE , TYPE ) "
                        "VALUES (:ID, :DATEE, :TYPE)");
          query.bindValue(0, id);
          query.bindValue(1, date);
          query.bindValue(2, type);


    return  query.exec();
}

QSqlQueryModel* audience::afficher(){

    QSqlQueryModel* model=new QSqlQueryModel();



          model->setQuery("SELECT* FROM AUDIANCE");
          model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
          model->setHeaderData(1, Qt::Horizontal, QObject::tr("DATE"));
          model->setHeaderData(2, Qt::Horizontal, QObject::tr("TYPE"));


  return model;
}
bool audience::supprimer(QString id_donnee)
{
    QSqlQuery query;

          query.prepare("Delete from AUDIANCE where id=:id" );

          query.bindValue(0, id_donnee);
 return query.exec();
}
bool audience ::modifier()
{
    QSqlQuery query;
 query.prepare("update AUDIANCE set datee=:datee,type=:type where id=:id");
 query.bindValue(":id", id);
 query.bindValue(":datee", date);
 query.bindValue(":type", type);




     return  query.exec();


}
