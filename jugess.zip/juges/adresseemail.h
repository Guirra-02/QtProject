#ifndef ADRESSEEMAIL_H
#define ADRESSEEMAIL_H
#include <QString>


class adresseemail
{
public:
    adresseemail();
   adresseemail(QString add, QString passwd = "");

    QString get_addresse();
    QString get_passwd();

    void setAddresse(const QString addresse);
    void setPasswd(const QString passwd);

private:
    QString add;
    QString password;
};



#endif // ADRESSEEMAIL_H
