#include "connection.h"
#include "QSqlDatabase"

connection::connection()
{

}
bool connection::createconnect()
{
    bool test=false;
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("PROJET2A");
db.setUserName("system");//inserer nom de l'utilisateur
db.setPassword("maram");//inserer mot de passe de cet utilisateur

if (db.open())
test=true;
return test;
}
void connection::closeconnection(){db.close();
}
