#include "adressemail.h"

adressemail::adressemail()
{

}
adressemail::adressemail(QString add, QString passwd){
    this->add = add;
    this->password = passwd;
}

QString adressemail::get_addresse()
{
    return add;
}

QString adressemail::get_passwd()
{
    return password;
}

void adressemail::setAddresse(const QString addresse)
{
    add = addresse;
}

void adressemail::setPasswd(const QString passwd)
{
    password = passwd;
}
