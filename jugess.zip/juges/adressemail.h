#ifndef ADRESSEMAIL_H
#define ADRESSEMAIL_H
#include <QString>


class adressemail
{
public:
    adressemail();
    adressemail(QString add, QString passwd = "");

    QString get_addresse();
    QString get_passwd();

    void setAddresse(const QString addresse);
    void setPasswd(const QString passwd);

private:
    QString add;
    QString password;
};

#endif // ADRESSEMAIL_H
