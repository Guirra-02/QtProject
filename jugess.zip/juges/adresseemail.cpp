#include "adresseemail.h"
#include <smtpjuge.h>
#include <email.h>

adresseemail::adresseemail()
{

}
adresseemail::adresseemail(QString add, QString passwd){
    this->add = add;
    this->password = passwd;
}

QString adresseemail::get_addresse()
{
    return add;
}

QString adresseemail::get_passwd()
{
    return password;
}

void adresseemail::setAddresse(const QString addresse)
{
    add = addresse;
}

void adresseemail::setPasswd(const QString passwd)
{
    password = passwd;
}
