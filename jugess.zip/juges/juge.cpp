#include "juge.h"
#include "ui_juge.h"
#include <QIntValidator>
#include "jugee.h"
#include "QMessageBox"
#include "QSqlQuery"
#include "QDebug"
#include "QSqlQueryModel"
#include <QObject>
#include <QPdfWriter>
#include <QPieSeries>
#include <QChart>
#include <QPieSlice>
#include <QBarSet>
#include <QBarSeries>
#include <QBarCategoryAxis>
#include <QtCharts/QLineSeries>
#include <QtCharts>
#include "qwidget.h"
#include "QSslSocket"
#include "stmp.h"
#include <QPrintDialog>
#include <QPrinter>



juge::juge(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::juge)
{

    ui->setupUi(this);
    ui->lineEdit_id->setValidator(new QIntValidator(100,99999999,this));
    //ui->stackedWidget_1->setCurrentIndex(0);
    ui->tableViewjuge->setModel(j.afficher());

    QSqlDatabase mydb=QSqlDatabase::addDatabase("QSQLITE");

    mydb.setDatabaseName("C:/oraclexe/app/oracle/product/11.2.0server/Get_Started.url");
    connect(ui->sendBtn, SIGNAL(clicked()),this, SLOT(sendMail()));
    connect(ui->browseBtn, SIGNAL(clicked()), this, SLOT(browse()));


}

juge::~juge()
{
    delete ui;

}

void juge::on_pushButton_retour_clicked()
{
    //ui->stackedWidget_1->setCurrentIndex(0);
    //ui->stackedWidget_1->setCurrentIndex(1);
    jugee j ;
         ui->tableViewjuge->setModel(j.afficher());


}


void juge::on_pushButton_ajout_clicked()
{


    QString nom=ui->lineEdit_nom->text();
    QString prenom=ui->lineEdit_prenom->text();
    QString dateN=ui->lineEdit_daten->text();
    QString num=ui->lineEdit_num->text();
    QString id=ui->lineEdit_id->text();
     QString lieuN =ui->lineEdit_lieun->text();
     QString grade =ui->lineEdit_grade->text();



   jugee j(nom,prenom,dateN,num,id,lieuN,grade);
    bool test=j.ajouter();
    if(test)
{

    QMessageBox::information(nullptr, QObject::tr("Ajout"),
                             QObject::tr("ajout successful .\n"
                                         "click cancel to exit"), QMessageBox::Cancel);
    ui->tableViewjuge->setModel(j.afficher());

}

else

{
    QMessageBox::critical(nullptr,QObject::tr("ajout!"),
                             QObject::tr("ajout failed .\n"
                                         "click cancel to exit"), QMessageBox::Cancel);}


    }






void juge::on_tableViewjuge_activated(const QModelIndex &index) //affichage liste
{


        QString val=ui->tableViewjuge->model()->data(index).toString();
        QSqlQuery q;
        q.prepare("select * from JUGESS where ID='"+val+"'");
        if(q.exec())
        {
            while (q.next()) {
                ui->lineEdit_nom->setText(q.value(0).toString());
                ui->lineEdit_prenom->setText(q.value(1).toString());
                ui->lineEdit_daten->setText(q.value(2).toString());
                ui->lineEdit_num->setText(q.value(3).toString());
                ui->lineEdit_id->setText(q.value(4).toString());
                ui->lineEdit_lieun->setText(q.value(5).toString());
                ui->lineEdit_grade->setText(q.value(6).toString());



            }
    }
}

void juge::on_pushButton_modifier_clicked()
{
    jugee j;
    QString nom =ui->lineEdit_nom->text();
     QString prenom =ui->lineEdit_prenom->text();
     QString grade=ui->lineEdit_grade->text();
     QString daten=ui->lineEdit_daten->text();
     QString lieun=ui->lineEdit_lieun->text();
      QString nu=ui->lineEdit_num->text();
      QString id =ui->lineEdit_id->text();


          bool test=j.modifier(id);
          if(test)
        {
              ui->lineEdit_id->setText("");
                       ui->lineEdit_nom->setText("");
                       ui->lineEdit_num->setText("");
                       ui->lineEdit_daten->setText("");
                       ui->lineEdit_grade->setText("");
                       ui->lineEdit_lieun->setText("");
                       ui->lineEdit_prenom->setText("");


                ui->tableViewjuge->setModel(j.afficher());//afficher tableau juge

        QMessageBox::information(nullptr, QObject::tr("modifier un juge"),
                          QObject::tr("modifié.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);

        }
          else
              QMessageBox::critical(nullptr, QObject::tr("modifier"),
                          QObject::tr("non modifié !.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);

}



void juge::on_pushButton_supp_clicked()
{
    jugee etmp;
   QString ID_juges= ui->lineEdit_supp->text();
        bool test = etmp.supprimer(ID_juges);
      if(test)
      {
          QMessageBox::information(nullptr, QObject::tr("ok"),
                            QObject::tr("suppression effectuee.\n"
                                     "Click Cancel to exit."), QMessageBox::Cancel);
          ui->tableViewjuge->setModel(etmp.afficher());

          }
            else
                QMessageBox::critical(nullptr, QObject::tr("not ok"),
                            QObject::tr("suppression non effectuee !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);





}


void juge::on_pushButton_recherche_clicked()
{


       QString rech=ui->lineEdit_rech->text();
       if(rech!="")  { ui->tableViewjuge->setModel(j.recherche(rech)); }
       else{// QMessageBox::information(this,"Pour chercher il Faut","tapez quelque chose !");
       ui->tableViewjuge->setModel(j.afficher());
   }
}

void juge::on_pushButton_asc_clicked()
{
    if(ui->comboBox->currentIndex()==0)
       ui->tableViewjuge->setModel(j.afficherup_id());
       else if(ui->comboBox->currentIndex()==1)
       ui->tableViewjuge->setModel(j.afficherup_num());

}


void juge::on_pushButton_dsc_clicked()
{
    if(ui->comboBox->currentIndex()==0)
       ui->tableViewjuge->setModel(j.afficherdown_id());
       else if(ui->comboBox->currentIndex()==1)
       ui->tableViewjuge->setModel(j.afficherdown_num());
}

void juge::on_pushButton_quitter_clicked()
{
     close();
}

void juge::on_pushButton_pdf_clicked()
{
    QString nom=ui->lineEdit_nom->text();
    QString prenom=ui->lineEdit_prenom->text();
    QString dateN=ui->lineEdit_daten->text();
     QString lieuN =ui->lineEdit_lieun->text();
     QString grade =ui->lineEdit_grade->text();
     QString nu=ui->lineEdit_num->text();
      QString id =ui->lineEdit_id->text();


    QPdfWriter pdf("C:/Users/LENOVO/Desktop/crud/juge.pdf");
      QPainter painter(&pdf);


     painter.setPen(Qt::red);
     painter.drawText(4000,400,"nom:"+nom+"");
     painter.setPen(Qt::black);
     painter.drawText(3000,1500,"prenom:"+prenom+"");
     painter.drawText(600,1000,"dateN:"+dateN+"");
     painter.drawText(800,1000,"lieuN:" +lieuN+"");
     painter.drawText(1000,1000,"grade:"+grade+"");

     painter.drawText(1000,600,"num:"+nu+"");
     painter.drawText(1000,1200,"lieuN:" +lieuN+"");
     painter.drawText(700,1000,"grade:"+grade+"");








     painter.end();

}

void juge::on_pushButton_Afficher_clicked()
{
    jugee j;
    ui->tableViewjuge->setModel(j.afficher());
}




void juge::on_pushButtonmail_clicked()
{

}

void juge::on_pushButton_envoyer_clicked() //annuler l'envoie
{

}


void juge::on_pushButton_annu_clicked()
{

}
void  juge::browse()
{
    files.clear();

    QFileDialog dialog(this);
    dialog.setDirectory(QDir::homePath());
    dialog.setFileMode(QFileDialog::ExistingFiles);

    if (dialog.exec())
        files = dialog.selectedFiles();

    QString fileListString;
    foreach(QString file, files)
        fileListString.append( "\"" + QFileInfo(file).fileName() + "\" " );

    ui->file->setText( fileListString );

}
void   juge::sendMail()
{
    Smtp* smtp = new Smtp("maram.njahi@esprit.tn ", ui->mail_pass->text(), "smtp.gmail.com");
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));

    if( !files.isEmpty() )
        smtp->sendMail("maram.njahi@esprit.tn", ui->rcpt->text() , ui->subject->text(),ui->msg->toPlainText(), files );
    else
        smtp->sendMail("maram.njahi@esprit.tn", ui->rcpt->text() , ui->subject->text(),ui->msg->toPlainText());
}
void   juge::mailSent(QString status)
{

    if(status == "Message sent")
        QMessageBox::warning( nullptr, tr( "Qt Simple SMTP client" ), tr( "Message sent!\n\n" ) );
    ui->rcpt->clear();
    ui->subject->clear();
    ui->file->clear();
    ui->msg->clear();
    ui->mail_pass->clear();
}




void juge::on_pushButton_im_clicked()
{

    QPrinter printer;
    printer.setPrinterName("test");
    QPrintDialog dialog(&printer, this);
    if (dialog.exec()==QDialog::Rejected) return;
}



void juge::on_pushButton_clicked()
{
    QSqlQueryModel * model= new QSqlQueryModel();
          model->setQuery("select * from JUGESS where LIEUN = 2");
          float dispo1=model->rowCount();

          model->setQuery("select * from JUGESS where LIEUN =1");
          float dispo=model->rowCount();

          float total=dispo1+dispo;
              QString a=QString(" LIEUN1 " +QString::number((dispo1*100)/total,'f',2)+"%" );
              QString b=QString(" LIEUN2  "+QString::number((dispo*100)/total,'f',2)+"%" );
              QPieSeries *series = new QPieSeries();
              series->append(a,dispo1);
              series->append(b,dispo);
          if (dispo1!=0)
          {QPieSlice *slice = series->slices().at(0);
              slice->setLabelVisible();
              slice->setPen(QPen());}
          if ( dispo!=0)
          {
              QPieSlice *slice1 = series->slices().at(1);
              slice1->setLabelVisible();
          }

          QChart *chart = new QChart();

          chart->addSeries(series);
          chart->setTitle("Les lieus: "+ QString::number(total));
          chart->legend()->hide();

          QChartView *chartView = new QChartView(chart);
          chartView->setRenderHint(QPainter::Antialiasing);
          chartView->resize(1000,500);
          chartView->show();
}


