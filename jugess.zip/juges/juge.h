#ifndef JUGE_H
#define JUGE_H

#include "jugee.h"
#include <QPieSeries>
#include <QChart>
#include <QPieSlice>
#include <QBarSet>
#include <QMainWindow>
#include <QBarSet>
#include <QPainter>



QT_BEGIN_NAMESPACE
namespace Ui { class juge; }
QT_END_NAMESPACE

class juge : public QMainWindow
{
    Q_OBJECT

public:
    juge(QWidget *parent = nullptr);
    ~juge();

private slots:
    void on_pushButton_ajout_clicked();

    void on_tableViewjuge_activated(const QModelIndex &index);

    void on_pushButton_modifier_clicked();

    void on_pushButton_supp_clicked();

    void on_pushButton_retour_clicked();

    void on_stackedWidget_1_currentChanged(int arg1);

    void on_pushButton_recherche_clicked();

    void on_pushButton_asc_clicked();

    void on_pushButton_dsc_clicked();

    void on_pushButton_quitter_clicked();

    void on_pushButton_pdf_clicked();

    void on_pushButton_Afficher_clicked();





    void on_pushButtonmail_clicked();

    void on_pushButton_envoyer_clicked();

    void on_pushButton_annu_clicked();
    void sendMail();
    void mailSent(QString);
    void browse();


    void on_pushButton_im_clicked();

    void on_calendarWidget1_activated(const QDate &date);

    void on_pushButton_i_clicked();

    void on_pushButton_im_pressed();

    void on_toolButton_im_clicked();

    void on_pushButton_clicked();

    void on_toolButton_im_triggered(QAction *arg1);

private:
    Ui::juge *ui;
    jugee j;
    jugee etmp;
    QStringList files;
    jugee e;


  //smtpjuge *jugeee;


};
#endif // JUGE_H
